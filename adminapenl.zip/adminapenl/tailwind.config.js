/** @type {import('tailwindcss').Config} */

module.exports = {
  content: ['*'],
  theme: {
    screens: {
      // 'Mobile': '0px',
      'Tablet': '768px', 
      'Laptop': '1024px', 
      'Desktop': '1280px', 
    },
    extend: {

      colors: {
        'Primary-c': '#4B49AC', 
        'White-c': '#ffffff',
        'Black-c': '#000000',
        'Indicates': '#f00b0b',
        'Dull-c': '#E0E3E8',
        'Dull-c2': '#C0BCBC',
        'Low-dull-c': '#f7f4f4' 
      },

    },

    fontFamily: {
      'roboto': ['"Roboto", sans-serif'],
    }

  },
  plugins: [],
}

