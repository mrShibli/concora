<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Test Mail</title>
</head>

<body>
    Test Mail
    <h1>{{ $maildata['title'] }}</h1>
    <h1>{{ $maildata['message'] }}</h1>
</body>

</html>
