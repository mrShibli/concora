<?php

namespace App\Models;

use App\Models\User;
use App\Models\JobPosition;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Applicant extends Model
{
    use HasFactory;

    protected $table = 'applicants';

    protected $fillable = [
        'position_id',
        'nationality',
        'first_name',
        'last_name',
        'mother_name',
        'father_name',
        'martialstatus',
        'emirates_expiry',
        'country',
        'province',
        'city',
        'zip',
        'homeaddrss',
        'nidorcnicnumber',
        'nidorcnicexpiry',
        'nid_cnic_front',
        'nid_cnic_back',
        'uaeresident',
        'emiratesid',
        'date_of_birth',
        'contact_number',
        'whatsapp_number',
        'email',
        'applicant_image',
        'applicant_passport',
        'passportno',
        'date_of_expiry',
        'applicant_resume',
        'specialpage',
        'submissionid',
        'otp',
        'otp_verified',
        'otp_generated_at',
        'reference',
    ];

    // Define relationship with Position model
    public function position()
    {
        return $this->belongsTo(JobPosition::class);
    }

    // Define relationship with User model
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
