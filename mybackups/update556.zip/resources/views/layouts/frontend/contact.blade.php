@extends('layouts.app')

@section('styles')
    <style>
        .myhidden {
            display: none;
        }
    </style>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/intl-tel-input@17.0.3/build/css/intlTelInput.css">
@endsection

@section('content')
    @if (Session::has('success'))
        <section>
            <div
                style="background-color: #d4edda; color: #155724; border-color: #c3e6cb; padding: .75rem 1.25rem; margin-bottom: 1rem; border: 1px solid transparent; border-radius: .25rem;font-size:1.3rem;">
                {{ Session::get('success') }}
            </div>
        </section>
    @endif

    <!-- --Page Heading Start--  -->
    <div class="page-heading contact">
        <section>
            <div class="content">
                <h2>We see the World Dierently</h2>
                <div class="menu-links">
                    <p style="color: #fff;">Best Deal for best making client realtionship to make business profitable
                    </p>
                </div>
            </div>

        </section>
    </div>
    <!-- --Page Heading End--  -->


    <!-- --Contact Page Content Start--  -->
    <section class="contact">

        <div class="location">
            <label for="input">Select Office Location:</label>
            <select id="input">
                <option value="office-address1">Registered Office (UAE) </option>
                <option value="office-address2">Canada Office </option>
                <option value="office-address3">USA Office</option>
                <option value="office-address4">UK Office</option>
                <option value="office-address5">Hong Kong Office</option>
                <option value="office-address6">Malaysia Office</option>
                <option value="office-address7">Turkey Office</option>
                <option value="office-address8">India Office</option>
            </select>

        </div>

        <div class="divider"></div>

        {{-- UAE Office Location Start --}}
        <div id="office-address1">
            <div class="contact-info">
                <div class="office-location">
                    <h4>Registered Office (UAE) :</h4>
                    <p> <a href="#"><i class="fas fa-map-marker-alt"></i> City Pharmacy Bld, M02, Port Saeed, Dubai</a> </p>
                    <p> <a href="mailto:info@conqueror.ae"><i class="fas fa-envelope"></i>info@conqueror.ae</a></p>
                    <p> <a href="tel:+97142837636"><i class="fas fa-phone"></i>+97142837636</a></p>
                    <p> <a href="www.conqueror.ae"><i class="fas fa-globe"></i>www.conqueror.ae</a></p>
                    <div class="social-icons">
                        <a href="#" class="fab fa-facebook"></a>
                        <a href="#" class="fab fa-twitter"></a>
                        <a href="#" class="fab fa-youtube"></a>
                        <a href="#" class="fab fa-linkedin"></a>
                        <a href="#" class="fab fa-whatsapp"></a>
                    </div>
                </div>
                <div class="map">
                    <iframe id="map"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3608.2370214261946!2d55.32939057371275!3d25.262610977668864!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f69636a8a7cd5%3A0x96c496f104f85162!2sCONQUEROR%20ASPIRATION%20LLC!5e0!3m2!1sen!2sbd!4v1711313796436!5m2!1sen!2sbd"></iframe>
                </div>
            </div>
        </div>
        {{-- UAE Office Location End --}}

        {{-- Canada Office Location Start --}}
        <div class="myhidden" id="office-address2">
            <div class="myhidden contact-info ">
                <div class="office-location">
                    <h4>Canada Office : </h4>
                    <p> <a href="#"><i class="fas fa-map-marker-alt"></i> 8321 Kennedy Road, Markham, ON L3R 5NR</a>
                    </p>
                    <p> <a href="mailto:info@conquerorgroup.ca"><i class="fas fa-envelope"></i>info@conquerorgroup.ca</a>
                    </p>

                    <div class="social-icons">
                        <a href="#" class="fab fa-facebook"></a>
                        <a href="#" class="fab fa-twitter"></a>
                        <a href="#" class="fab fa-youtube"></a>
                        <a href="#" class="fab fa-linkedin"></a>
                        <a href="#" class="fab fa-whatsapp"></a>
                    </div>
                </div>
                <div class="map">
                    <iframe id="map"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2876.978903274957!2d-79.30709132464695!3d43.856265939274735!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d4d5c7bfcaa3ef%3A0xcf8de667526a73d6!2sCONQUEROR%20ASPIRATION%20LTD!5e0!3m2!1sen!2sbd!4v1710122554439!5m2!1sen!2sbd"></iframe>
                </div>
            </div>
        </div>
        {{-- Canada Office Location End --}}

        {{-- USA Office Location Start --}}
        <div class="myhidden" id="office-address3">
            <div class="myhidden contact-info ">
                <div class="office-location">
                    <h4>USA Office : </h4>
                    <p> <a href="#"><i class="fas fa-map-marker-alt"></i> 5900 Balcones Dr,Austin, TX 7831, USA</a>
                    </p>
                    <p> <a href="mailto:contact@conquerorgroup.us"><i
                                class="fas fa-envelope"></i>contact@conquerorgroup.us</a>
                    </p>

                    <div class="social-icons">
                        <a href="#" class="fab fa-facebook"></a>
                        <a href="#" class="fab fa-twitter"></a>
                        <a href="#" class="fab fa-youtube"></a>
                        <a href="#" class="fab fa-linkedin"></a>
                        <a href="#" class="fab fa-whatsapp"></a>
                    </div>
                </div>
                <div class="map">
                    <iframe id="map"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3443.33022797876!2d-97.75752952535542!3d30.341563504433825!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8644cae2feb064b3%3A0xfbcc19243aa6ddc0!2s5900%20Balcones%20Dr%2C%20Austin%2C%20TX%2078731%2C%20USA!5e0!3m2!1sen!2sbd!4v1710124224433!5m2!1sen!2sbd"></iframe>
                </div>
            </div>
        </div>
        {{-- USA Office Location End --}}

        {{-- UK Office Location Start --}}
        <div class="myhidden" id="office-address4">
            <div class="myhidden contact-info ">
                <div class="office-location">
                    <h4>UK Office : </h4>
                    <p> <a href="#"><i class="fas fa-map-marker-alt"></i> 71-75, Shelton Street, Covent Garden, London WC2H 9JQ, United Kingdom</a>
                    </p>
                    <p> <a href="mailto:info@conquerorgroup.co.uk"><i
                                class="fas fa-envelope"></i>info@conquerorgroup.co.uk</a>
                    </p>

                    <div class="social-icons">
                        <a href="#" class="fab fa-facebook"></a>
                        <a href="#" class="fab fa-twitter"></a>
                        <a href="#" class="fab fa-youtube"></a>
                        <a href="#" class="fab fa-linkedin"></a>
                        <a href="#" class="fab fa-whatsapp"></a>
                    </div>
                </div>
                <div class="map">
                    <iframe id="map"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2482.908008287716!2d-0.1261591245294574!3d51.5149036718151!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4876053aa6e389e3%3A0x1ed55edd887442d!2s71-75!5e0!3m2!1sen!2sbd!4v1711313976016!5m2!1sen!2sbd"></iframe>
                </div>
            </div>
        </div>
        {{-- UK Office Location End --}}

        {{-- Hong Kong Office Location Start --}}
        <div class="myhidden" id="office-address5">
            <div class="myhidden contact-info ">
                <div class="office-location">
                    <h4>Hong Kong Office :</h4>
                    <p> <a href="#"><i class="fas fa-map-marker-alt"></i> Flat B, 6/F, MEI FA Building, 25-35,
                            Shanghai Street, Jordan, Kowloon</a>
                    </p>
                    <p> <a href="mailto:info@conquerorllc.com"><i class="fas fa-envelope"></i>info@conquerorllc.com</a>
                    </p>

                    <div class="social-icons">
                        <a href="#" class="fab fa-facebook"></a>
                        <a href="#" class="fab fa-twitter"></a>
                        <a href="#" class="fab fa-youtube"></a>
                        <a href="#" class="fab fa-linkedin"></a>
                        <a href="#" class="fab fa-whatsapp"></a>
                    </div>
                </div>
                <div class="map">
                    <iframe id="map"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3691.3180647692366!2d114.16646197434481!3d22.30380764277017!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x340400eb5e668edb%3A0x8b82a364291432c6!2s25%20Shanghai%20Street%2C%2025%20Shanghai%20St%2C%20Yau%20Ma%20Tei%2C%20Hong%20Kong!5e0!3m2!1sen!2sbd!4v1710124795948!5m2!1sen!2sbd"></iframe>
                </div>
            </div>
        </div>
        {{-- Hong Kong Office Location End --}}

        {{-- Malaysia Office Location Start --}}
        <div class="myhidden" id="office-address6">
            <div class="myhidden contact-info ">
                <div class="office-location">
                    <h4>Malaysia Office : </h4>
                    <p> <a href="#"><i class="fas fa-map-marker-alt"></i> 12 Jalan Kuchai Maju B, Kuala Lumpur
                            58200</a>
                    </p>
                    <p> <a href="mailto:info@conquerorllc.com"><i class="fas fa-envelope"></i>info@conquerorllc.com</a>
                    </p>

                    <div class="social-icons">
                        <a href="#" class="fab fa-facebook"></a>
                        <a href="#" class="fab fa-twitter"></a>
                        <a href="#" class="fab fa-youtube"></a>
                        <a href="#" class="fab fa-linkedin"></a>
                        <a href="#" class="fab fa-whatsapp"></a>
                    </div>
                </div>
                <div class="map">
                    <iframe id="map"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.023459874899!2d101.6866465740336!3d3.088411353524963!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc4a6c90ee3be7%3A0x17d962c5637e2f01!2sYonex%20Concept%20Store%20by%20Vsmash!5e0!3m2!1sen!2sbd!4v1710124940604!5m2!1sen!2sbd"></iframe>
                </div>
            </div>
        </div>
        {{-- Malaysia Office Location End --}}

        {{-- Turkey Office Location Start --}}
        <div class="myhidden" id="office-address7">
            <div class="myhidden contact-info ">
                <div class="office-location">
                    <h4>Turkey Office :</h4>
                    <p> <a href="#"><i class="fas fa-map-marker-alt"></i>Konak Mahallesi, Bursa, 16110</a>
                    </p>
                    <p> <a href="mailto:info@conqueror.com.tr"><i class="fas fa-envelope"></i>info@conqueror.com.tr</a>
                    </p>

                    <div class="social-icons">
                        <a href="#" class="fab fa-facebook"></a>
                        <a href="#" class="fab fa-twitter"></a>
                        <a href="#" class="fab fa-youtube"></a>
                        <a href="#" class="fab fa-linkedin"></a>
                        <a href="#" class="fab fa-whatsapp"></a>
                    </div>
                </div>
                <div class="map">
                    <iframe id="map"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12188.490818164515!2d28.97083870006965!3d40.206333381443464!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14ca169e9739dc3d%3A0x5979340547076e0a!2zS29uYWssIDE2MTEwIE5pbMO8ZmVyL0J1cnNhLCBUw7xya2l5ZQ!5e0!3m2!1sen!2sbd!4v1710125065546!5m2!1sen!2sbd"></iframe>
                </div>
            </div>
        </div>
        {{-- Turkey Office Location End --}}

        {{-- India Office Location Start --}}
        <div class="myhidden" id="office-address8">
            <div class="myhidden contact-info ">
                <div class="office-location">
                    <h4>India Office : </h4>
                    <p> <a href="#"><i class="fas fa-map-marker-alt"></i>World Trade Tower, Connaught Place, Delhi
                            110001 </a>
                    </p>
                    <p> <a href="mailto:info@conquerorllc.com"><i class="fas fa-envelope"></i>info@conquerorllc.com</a>
                    </p>

                    <div class="social-icons">
                        <a href="#" class="fab fa-facebook"></a>
                        <a href="#" class="fab fa-twitter"></a>
                        <a href="#" class="fab fa-youtube"></a>
                        <a href="#" class="fab fa-linkedin"></a>
                        <a href="#" class="fab fa-whatsapp"></a>
                    </div>
                </div>
                <div class="map">
                    <iframe id="map"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.955024265417!2d77.22442667457283!3d28.631110034146936!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfd5f17b7a30f%3A0xd539b39d7e4aae29!2sWorld%20Trade%20Tower!5e0!3m2!1sen!2sbd!4v1710125188196!5m2!1sen!2sbd"></iframe>
                </div>
            </div>
        </div>
        {{-- India Office Location End --}}

        <form method="POST" action="{{ route('contact.store') }}" class="form">
            @csrf
            <h2>Send your message to us</h2>

            <div class="box">
                <div class="bx">
                    <label for="name">First Name</label>
                    <input type="text" name="fname">
                    @error('fname')
                        <p class="erromessage">{{ $message }}</p>
                    @enderror
                </div>
                <div class="bx">
                    <label for="lname">Last Name</label>
                    <input type="text" name="lname">
                    @error('lname')
                        <p class="erromessage">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <div class="box">
                <div class="bx contactdd">
                    <label for="phone_number">Phone Number</label>
                    <input type="tel" name="phone_number" id="phone_number">
                    @error('phone_number')
                        <p class="erromessage">{{ $message }}</p>
                    @enderror
                </div>
                <div class="bx">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="">
                    @error('email')
                        <p class="erromessage">{{ $message }}</p>
                    @enderror
                </div>
            </div>


            <label for="subject">Subject</label>
            <input type="text" name="subject" id="">
            @error('subject')
                <p class="erromessage">{{ $message }}</p>
            @enderror

            <label for="message">Message</label>
            <textarea name="message" id="" cols="30" rows="12"></textarea>
            @error('subjmessageect')
                <p class="erromessage">{{ $message }}</p>
            @enderror

            <input type="submit" name="Submit" class="btn">

        </form>

    </section>
    <!-- --Contact Page Content End--  -->
    
@endsection

@section('scripts')
    <script>
        const input = document.getElementById('input');
        const sections = {
            'office-address1': document.getElementById('office-address1'),
            'office-address2': document.getElementById('office-address2'),
            'office-address3': document.getElementById('office-address3'),
            'office-address4': document.getElementById('office-address4'),
            'office-address5': document.getElementById('office-address5'),
            'office-address6': document.getElementById('office-address6'),
            'office-address7': document.getElementById('office-address7'),
            'office-address8': document.getElementById('office-address8')
        };

        input.addEventListener('change', function() {
            const selectedOption = input.value;
            for (const key in sections) {
                if (key === selectedOption) {
                    sections[key].classList.remove('myhidden');
                } else {
                    sections[key].classList.add('myhidden');
                }
            }
        });

        // Initially hide all sections except office-address1
        for (const key in sections) {
            if (key !== 'office-address1') {
                sections[key].classList.add('myhidden');
            }
        }
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>


    <script src="https://cdn.jsdelivr.net/npm/intl-tel-input@17.0.3/build/js/intlTelInput.min.js"></script>
    <script>
        var phone_number_contact = window.intlTelInput(document.querySelector("#phone_number"), {
            separateDialCode: true,
            preferredCountries: ["ae"],
            hiddenInput: "full",
            utilsScript: "//cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/utils.js"
        });

        $("form").submit(function() {
            var full_number_con = phone_number_contact.getNumber(intlTelInputUtils.numberFormat.E164);
            $("input[name='phone_number'").val(full_number_con);
        });
    </script>
@endsection
