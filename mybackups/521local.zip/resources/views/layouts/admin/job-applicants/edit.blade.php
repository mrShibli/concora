@extends('layouts.master')

@section('styles')
    <style>
        .form-check {
            margin-left: 25px;
            margin-bottom: 21px;
            margin-top: -4px;
        }

        .message {
            font-size: 12px;
            margin-bottom: 5px;
            margin-top: 10px;
        }
    </style>
@endsection

@section('content')
    <div class="content-wrapper">
        @if (Session::has('success'))
            <div class="alert alert-success">
                {{ Session::get('success') }}
            </div>
        @endif
        @if ($errors->any())
            <div class="center allerror">
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            </div>
        @endif
        @if (Auth::user()->role == 'user')
            <nav aria-label="breadcrumb" class="mt-2">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item "> <a href="{{ route('applicants.index') }}"> Home </a> </li>
                    <li class="breadcrumb-item"><a href="{{ route('applicants.index') }}">Applicants </a>
                    <li class="breadcrumb-item active"><a
                            href="{{ route('applicants.editappli', ['id' => $applicant->id]) }}"> Edit </a>
                    </li>
                </ol>
            </nav>
        @elseif(true)
            <nav aria-label="breadcrumb" class="mt-2">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item "> <a href="{{ route('dashboard') }}"> Home </a> </li>
                    <li class="breadcrumb-item"><a href="{{ route('applicants.index') }}">Applicants </a>
                    <li class="breadcrumb-item active"><a
                            href="{{ route('applicants.editappli', ['id' => $applicant->id]) }}"> Edit </a>
                    </li>
                </ol>
            </nav>
        @endif
        <h3 class="pt-3 p-1">Edit/Update Applicant</h3>

        <form method="POST" action="{{ route('applicants.update', $applicant->id) }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <div class="row">
                <div class="col-md-6">

                    <input type="hidden" class="form-control" name="position_id" value="{{ $applicant->position_id }}">

                    <div class="form-group">
                        <label for="nationality">Nationality:</label>
                        <input type="text" class="form-control" name="nationality" value="{{ $applicant->nationality }}"
                            required>
                    </div>

                    <div class="form-group">
                        <label for="first_name">First Name:</label>
                        <input type="text" class="form-control" name="first_name" value="{{ $applicant->first_name }}"
                            required>
                    </div>

                    <div class="form-group">
                        <label for="last_name">Last Name:</label>
                        <input type="text" class="form-control" name="last_name" value="{{ $applicant->last_name }}"
                            required>
                    </div>

                    <div class="form-group">
                        <label for="mother_name">Mother Name:</label>
                        <input type="text" class="form-control" name="mother_name"
                            value="{{ $applicant->mother_name }}">
                    </div>

                    <div class="form-group">
                        <label for="contact_number">Contact Number:</label>
                        <input type="text" class="form-control" name="contact_number"
                            value="{{ $applicant->contact_number }}" required>
                    </div>

                    <div class="form-group">
                        <label for="whatsapp_number">WhatsApp Number:</label>
                        <input type="text" class="form-control" name="whatsapp_number"
                            value="{{ $applicant->whatsapp_number }}" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" name="email" value="{{ $applicant->email }}" required>
                    </div>

                    <div class="form-group">

                        @if ($applicant->otp_verified == 0)
                            <a href="{{ route('applicants.verifyemailadmin', ['id' => $applicant->id]) }}"
                                class="btn btn-danger rounded">Verify Email</a>

                            @if (Session::has('otpstatus'))
                                <div class="mt-2 verifyarea">
                                    <div class="message"></div>
                                    <input type="number" class="form-control" id="verifemailmanual"
                                        name="verifemailmanual" placeholder="Enter OTP here">
                                    <a class="btn btn-success rounded mt-2" id="verifynowbutton">Verify Now</a>
                                </div>
                            @endif
                        @else
                            <a href="" class="btn btn-success rounded disabled">Email Verified</a>
                        @endif

                    </div>


                    <div class="form-group">
                        <label for="uaeresident">UAE Resident :</label>
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" name="uaeresident" id="uaeresident"
                                {{ $applicant->uaeresident ? 'checked' : '' }}>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="emiratesid">Emirates ID:</label>
                        <input type="text" class="form-control" name="emiratesid" value="{{ $applicant->emiratesid }}">
                    </div>

                    <div class="form-group">
                        <label for="date_of_birth">Date of Birth:</label>
                        <input type="date" class="form-control" name="date_of_birth"
                            value="{{ $applicant->date_of_birth }}" required>
                    </div>

                    <div class="form-group border p-2">
                        <label for="appli_dri_lisence_backpart">Driving License Back:</label>
                        <input type="file" class="form-control-file" name="appli_dri_lisence_backpart">

                        <small>(Upload if want to update)</small>
                        @if ($applicant->appli_dri_lisence_backpart)
                            <!--Existing Driving License Front -->
                            <div class="mb-4">
                                <p class="pt-1"></p>
                                <strong>Current Driving License Back:</strong><br>
                                <embed src="{{ asset('applicants/' . $applicant->appli_dri_lisence_backpart) }}"
                                    width="100px" height="100px" /> <br>
                                <a href="{{ asset('applicants/' . $applicant->appli_dri_lisence_backpart) }}"> View
                                    Driving License Back </a>

                            </div>
                        @else
                            <h5 style="color: rgb(141, 15, 15);" class="mt-2">Applicant has not uploaded Driving License
                                Back.</h5>
                        @endif

                    </div>

                    <div class="form-group border p-2">
                        <label for="specialpage">Special Page:</label>
                        <input type="file" class="form-control-file" name="specialpage" id="specialpage">
                        <small>(Upload if want to update)</small>
                        @if ($applicant->specialpage)
                            <!--Existing Driving License Front -->
                            <div class="mb-4">
                                <p class="pt-1"></p>
                                <strong>Current Special Page:</strong><br>
                                <embed src="{{ asset('applicants/' . $applicant->specialpage) }}" width="100px"
                                    height="100px" /> <br>
                                <a href="{{ asset('applicants/' . $applicant->specialpage) }}"> View
                                    Special Page </a>

                            </div>
                        @else
                            <h5 style="color: rgb(141, 15, 15);" class="mt-2">Applicant has not uploaded Special Page.
                            </h5>
                        @endif
                    </div>

                    <div class="form-group">
                        <label for="passportno">Passport Number:</label>
                        <input type="text" class="form-control" name="passportno"
                            value="{{ $applicant->passportno }}">
                    </div>

                    <div class="form-group">
                        <label for="date_of_expiry">Passport Expiry Date:</label>
                        <input type="date" class="form-control" name="date_of_expiry"
                            value="{{ $applicant->date_of_expiry }}">
                    </div>

                    <div class="form-group">
                        <label for="reference">Reference:</label>
                        {{ in_array($applicant->reference, ['PK2024S7', 'KP2024P3', 'MS2024K8', 'MN2024U5', 'SZ2024A9']) ? $applicant->reference : '( Not Matched )' }}
                        <input type="text" class="form-control" name="reference"
                            value="{{ $applicant->reference }}">
                    </div>

                </div>

                <div class="col-md-6">

                    <div class="form-group border p-2">
                        <label for="applicant_image">Applicant Image:</label>
                        <input type="file" class="form-control-file" name="applicant_image">

                        <small>(Upload if want to update)</small>

                        @if ($applicant->applicant_image)
                            <!--Existing Profile image -->
                            <div class="mb-4">
                                <p class="pt-1"></p>
                                <strong>Current Image: </strong><br>

                                <a href="{{ asset('applicants/' . $applicant->applicant_image) }}"
                                    data-lightbox="image-set" data-title="Applicant Image">
                                    <img src="{{ asset('applicants/' . $applicant->applicant_image) }}" width="70"
                                        class="img-thumbnail mt-1 mb-1" alt="Applicant Image">
                                </a>
                            </div>
                        @else
                            <h5 style="color: rgb(141, 15, 15);" class="mt-2">Applicant has not uploaded an image.</h5>
                        @endif
                    </div>

                    <div class="form-group border p-2">
                        <label for="nid_cnic_front">Applicant NID/CNIC Front:</label>
                        <input type="file" class="form-control-file" name="nid_cnic_front">

                        <small>(Upload if want to update)</small>
                        @if ($applicant->applicant_passport)
                            <!--Existing Passport -->
                            <div class="mb-4">
                                <p class="pt-1"></p>
                                <strong>Current NID/CNIC Front:</strong><br>
                                <embed src="{{ asset('applicants/' . $applicant->nid_cnic_front) }}" width="100px"
                                    height="100px" /> <br>
                                <a href="{{ asset('applicants/' . $applicant->nid_cnic_front) }}"> View NID/CNIC Front
                                </a>

                            </div>
                        @else
                            <h5 style="color: rgb(141, 15, 15);" class="mt-2">Applicant has not uploaded NID/CNIC Front.
                            </h5>
                        @endif
                    </div>

                    <div class="form-group border p-2">
                        <label for="nid_cnic_back">Applicant NID/CNIC Back:</label>
                        <input type="file" class="form-control-file" name="nid_cnic_back">

                        <small>(Upload if want to update)</small>
                        @if ($applicant->nid_cnic_back)
                            <!--Existing Passport -->
                            <div class="mb-4">
                                <p class="pt-1"></p>
                                <strong>Current NID/CNIC Back:</strong><br>
                                <embed src="{{ asset('applicants/' . $applicant->nid_cnic_back) }}" width="100px"
                                    height="100px" /> <br>
                                <a href="{{ asset('applicants/' . $applicant->nid_cnic_back) }}"> View NID/CNIC Back </a>

                            </div>
                        @else
                            <h5 style="color: rgb(141, 15, 15);" class="mt-2">Applicant has not uploaded NID/CNIC Back.
                            </h5>
                        @endif
                    </div>

                    <div class="form-group border p-2">
                        <label for="applicant_passport">Applicant Passport:</label>
                        <input type="file" class="form-control-file" name="applicant_passport">

                        <small>(Upload if want to update)</small>
                        @if ($applicant->applicant_passport)
                            <!--Existing Passport -->
                            <div class="mb-4">
                                <p class="pt-1"></p>
                                <strong>Current Passport:</strong><br>
                                <embed src="{{ asset('applicants/' . $applicant->applicant_passport) }}" width="100px"
                                    height="100px" /> <br>
                                <a href="{{ asset('applicants/' . $applicant->applicant_passport) }}"> View Passport </a>

                            </div>
                        @else
                            <h5 style="color: rgb(141, 15, 15);" class="mt-2">Applicant has not uploaded passport.</h5>
                        @endif

                    </div>

                    <div class="form-group border p-2">
                        <label for="applicant_resume">Applicant Resume:</label>
                        <input type="file" class="form-control-file" name="applicant_resume">

                        <small>(Upload if want to update)</small>
                        @if ($applicant->applicant_resume)
                            <!--Existing Resume -->
                            <div class="mb-4">
                                <p class="pt-1"></p>
                                <strong>Current Resume:</strong><br>
                                <embed src="{{ asset('applicants/' . $applicant->applicant_resume) }}" width="100px"
                                    height="100px" /> <br>
                                <a href="{{ asset('applicants/' . $applicant->applicant_resume) }}"> View Resume </a>

                            </div>
                        @else
                            <h5 style="color: rgb(141, 15, 15);" class="mt-2">Applicant has not uploaded resume.</h5>
                        @endif

                    </div>

                    <div class="form-group border p-2">
                        <label for="appli_dri_lisence_frontpart">Driving License Front:</label>
                        <input type="file" class="form-control-file" name="appli_dri_lisence_frontpart">

                        <small>(Upload if want to update)</small>
                        @if ($applicant->appli_dri_lisence_frontpart)
                            <!--Existing Driving License Front -->
                            <div class="mb-4">
                                <p class="pt-1"></p>
                                <strong>Current Driving License Front:</strong><br>
                                <embed src="{{ asset('applicants/' . $applicant->appli_dri_lisence_frontpart) }}"
                                    width="100px" height="100px" /> <br>
                                <a href="{{ asset('applicants/' . $applicant->appli_dri_lisence_frontpart) }}"> View
                                    Driving License Front </a>

                            </div>
                        @else
                            <h5 style="color: rgb(141, 15, 15);" class="mt-2">Applicant has not uploaded Driving License
                                Front.</h5>
                        @endif

                    </div>

                    <div class="form-group">
                        <label for="appli_dri_number">Driving License Number:</label>
                        <input type="text" class="form-control" name="appli_dri_number"
                            value="{{ $applicant->appli_dri_number }}">
                    </div>

                    <div class="form-group">
                        <label for="otp_verified">OTP Verified:</label>
                        <input type="checkbox" class="form-check-input ml-3" name="otp_verified" id="otp_verified"
                            {{ $applicant->otp_verified == 1 ? 'checked' : '' }}> <br>
                        ( {{ $applicant->otp_verified == 1 ? 'Verified' : 'Not Verified' }} )
                    </div>


                </div>
            </div>

            <input type="hidden" name="submissionid" value="{{ $applicant->submissionid }}">
            <input type="hidden" name="otp_generated_at" value="{{ $applicant->otp_generated_at }}">

            <button type="submit" class="btn btn-primary">Update Applicant</button>
        </form>

    </div>
@endsection

@section('script')
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <script>
        $(document).ready(function() {
            $('#verifynowbutton').click(function() {
                var inputval = $('#verifemailmanual').val();
                $.ajax({
                    url: '{{ route('applicants.verifyemailadminotp') }}',
                    method: 'POST',
                    data: {
                        otpcode: inputval,
                        _token: '{{ csrf_token() }}',
                    },
                    success: function(response) {
                        $('.message').text(response.message + ' OTP: ' + response
                            .otp);
                        if (response.mainotp == response.otp) {
                            setTimeout(function() {
                                location.reload();
                            }, 3000);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error:', error);
                    }
                });
            });

        });
    </script>
@endsection
