@extends('layouts.master')

@section('content')
    <div class="content-wrapper">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item "> <a href="{{ route('dashboard') }}"> Home </a> </li>
                <li class="breadcrumb-item bactive"><a href="{{ route('applicants.index') }}"> Applicants </a>
                </li>
            </ol>
        </nav>
        <div class="row">
            @if (Session::has('success'))
                <div class="alert alert-success">
                    {{ Session::get('success') }}
                </div>
            @endif
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <p class="card-title mb-2">Riders Job Applications</p>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered mt-3" id="jobapplicants">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>FName</th>
                                        <th>Position</th>
                                        <th>Contact</th>
                                        <th>Submitted</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse ($applicants as $applicant)
                                        <tr>
                                            <td>{{ $loop->index + 1 }}</td>
                                            <td>{{ $applicant->first_name }}</td>
                                            <td>{{ $applicant->position->title ?? 'Position Not Found' }}</td>
                                            <td>{{ $applicant->email }}</td>
                                            <td>{{ $applicant->created_at->format('F d, Y') }}</td>
                                            <td>

                                                <!-- View data link -->
                                                <a href="{{ route('applicants.show', ['id' => $applicant->id]) }}"
                                                    class="btn p-0">
                                                    <img src="{{ asset('view.svg') }}" style="width: 27px !important;">
                                                </a>

                                                @auth
                                                    @if (Auth::user()->role == 1)
                                                        <form
                                                            action="{{ route('applicant.destroy', ['id' => $applicant->id]) }}"
                                                            method="POST" style="display: inline;">
                                                            @csrf
                                                            @method('DELETE')
                                                            <button type="submit" class="btn p-0"
                                                                onclick="return confirm('Are you sure you want to delete this item?')">
                                                                <img src="{{ asset('delete.svg') }}"
                                                                    style="width: 27px !important;">
                                                            </button>
                                                        </form>
                                                    @endif
                                                @endauth

                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="3">No data available</td>
                                        </tr>
                                    @endforelse

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(document).ready(function() {
            $('#jobapplicants').DataTable();
        });
    </script>
@endsection
