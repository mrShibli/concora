@extends('layouts.master')

@section('content')
    <div class="content-wrapper">
        @if (Session::has('message'))
            <div class="alert alert-success">
                {{ Session::get('message') }}
            </div>
        @endif
        <div class="row">

            <div class="col-md-12 grid-margin">

                <div class="row">
                    <div class="col-12 col-xl-8 mb-4 mb-xl-0">
                        <h3 class="font-weight-bold">Welcome Admin!</h3>
                        <h6 class="font-weight-normal mb-0"> All systems are running smoothly! </h6>
                    </div>
                    <div class="col-12 col-xl-4">
                        <div class="justify-content-end d-flex">
                            <div class="dropdown flex-md-grow-1 flex-xl-grow-0">
                                <button class="btn btn-sm btn-light bg-white dropdown-toggle" type="button"
                                    id="dropdownMenuDate2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                    <i class="mdi mdi-calendar"></i> Today
                                    ({{ \Carbon\Carbon::now()->format('d M Y') }})
                                </button>
                                {{-- <div class="dropdown-menu dropdown-menu-right"
                                aria-labelledby="dropdownMenuDate2">
                                <a class="dropdown-item" href="#">January - March</a>
                                <a class="dropdown-item" href="#">March - June</a>
                                <a class="dropdown-item" href="#">June - August</a>
                                <a class="dropdown-item" href="#">August - November</a>
                            </div> --}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 grid-margin stretch-card">
                <div class="card tale-bg">
                    <div class="card-people mt-auto">
                        <img src="images/dashboard/people.svg" alt="people">
                        <div class="weather-info">

                            {{-- <div class="d-flex">
                            <div>
                                <h2 class="mb-0 font-weight-normal"><i
                                        class="icon-sun mr-2"></i>31<sup>C</sup></h2>
                            </div>
                            <div class="ml-2">
                                <h4 class="location font-weight-normal">Bangalore</h4>
                                <h6 class="font-weight-normal">India</h6>
                            </div>
                        </div> --}}

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 grid-margin transparent">
                <div class="row">
                    <div class="col-md-6 mb-4 stretch-card transparent">
                        <div class="card card-tale">
                            <div class="card-body">
                                <a href="{{ route('applicants.index') }}" style="color: #fff">
                                    <p class="mb-4">Applicant Requests</p>
                                    <p class="fs-30 mb-2">{{ $JobApplicant }}</p>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4 stretch-card transparent">
                        <div class="card card-dark-blue">
                            <div class="card-body">
                                <a href="{{ route('admin.contact') }}" style="color: #fff">
                                    <p class="mb-4">Contacts</p>
                                    <p class="fs-30 mb-2">{{ $contactscount }}</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-4 mb-lg-0 stretch-card transparent">
                        <div class="card card-light-blue">
                            <div class="card-body">
                                <a href="{{ route('qauotation.index') }}" style="color: #fff">
                                    <p class="mb-4">Request Quotation</p>
                                    <p class="fs-30 mb-2">{{ $quotation }}</p>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 stretch-card transparent">
                        <div class="card card-light-danger">
                            <div class="card-body">
                                <a href="{{ route('job_positions.index') }}" style="color: #fff">
                                    <p class="mb-5 ">Job Positions</p>
                                    <p class="fs-30 mb-2">{{ $jobpositions }}</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 grid-margin transparent">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 mb-2 stretch-card transparent">
                            <div class="card card-tale">
                                
                                <div class="card-body">
                                    <a href="{{ route('applicants.indexverified') }}" style="color: #fff">
                                        <p class="mb-2">Verified Applicants</p>
                                        <p class="fs-30">{{ $JobApplicantOtpVerified }}</p>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 mb-2 stretch-card transparent">
                            <div class="card card-dark-blue">
                                <div class="card-body">
                                    <a href="{{ route('applicants.notverified') }}" style="color: #fff">
                                        <p class="mb-2">Not Verified</p>
                                        <p class="fs-30">{{ $JobApplicantOtpNotVerified }}</p>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 mb-2 stretch-card transparent">
                            <div class="card card-dark-blue">
                                <div class="card-body">
                                    <a href="{{ route('applicants.invited') }}" style="color: #fff">
                                        <p class="mb-2">Invited for Interview</p>
                                        <p class="fs-30">{{ $JobApplicantInvited }}</p>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 mb-2 stretch-card transparent">
                            <div class="card card-light-blue">
                                <div class="card-body">
                                    <a href="{{ route('applicants.hired') }}" style="color: #fff">
                                        <p class="mb-2">Hired</p>
                                        <p class="fs-30">{{ $JobApplicantHired }}</p>
                                    </a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>


        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <p class="card-title mb-2">Latest Job Applications</p>
                        <div class="table-responsive">
                            <table class="table table-bordered mt-3" id="latestjobapplicants">
                                <thead class="bg-info text-white">
                                    <tr>
                                        <th>SL</th>
                                        <th>First Name</th>
                                        <th>Country</th>
                                        <th>Position</th>
                                        <th>Contact No</th>
                                        <th>Email</th>
                                        <th>Submitted</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse ($applicants as $applicant)
                                        <tr class="{{ $applicant->viewed > 0 ? 'viewed' : 'notviewed' }}">
                                            <td>{{ $loop->index + 1 }}</td>
                                            <td>{{ $applicant->first_name }}</td>
                                            <td>{{ $applicant->nationality }}</td>
                                            <td>{{ $applicant->position->title ?? 'Position Not Found' }}</td>
                                            <td>{{ $applicant->contact_number }}</td>
                                            <td>{{ $applicant->email }}</td>
                                            <td>{{ $applicant->created_at->format('F d, Y') }}</td>
                                            <td>
                                                <!-- View data link -->
                                                <a href="{{ route('applicants.show', ['id' => $applicant->id]) }}"
                                                    class="dbtn">
                                                    <img src="{{ asset('view.svg') }}" style="width: 27px !important;">
                                                </a>

                                                <!-- Edit data link -->
                                                <a href="{{ route('applicants.editappli', ['id' => $applicant->id]) }}"
                                                    class="btn p-0">
                                                    <img src="{{ asset('edit.svg') }}" style="width: 27px !important;">
                                                </a>

                                                <form action="{{ route('applicant.destroy', ['id' => $applicant->id]) }}"
                                                    method="POST" style="display: inline;">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="dbtn"
                                                        onclick="return confirm('Are you sure you want to delete this item?')">
                                                        <img src="{{ asset('delete.svg') }}"
                                                            style="width: 27px !important;">
                                                    </button>
                                                </form>

                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="3">No data available</td>
                                        </tr>
                                    @endforelse

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(document).ready(function() {
            $('#latestjobapplicants').DataTable();
        });
    </script>
@endsection
