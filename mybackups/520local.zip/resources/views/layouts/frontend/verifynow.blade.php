@extends('layouts.appwithoutheaderfooter')

@section('styles')
    <style>
        .errorveirifymessage {
            background-color: #f58b2712;
            color: #ff3f3f;
            border-color: #f35d5d14;
            padding: .75rem 1.25rem;
            margin-bottom: 1rem;
            border: 1px solid transparent;
            border-radius: .25rem;
            font-size: 1.5rem;
            text-align: left;
            margin-top: 10px;

        }

        div#countdown {
            font-size: 40px;
        }
    </style>
@endsection

@section('content')
    @if ($message = request()->query('verifymessage'))
        <section style="display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100vh;">

            <!-- Display countdown clock -->
            <div id="countdown"></div>

            <script>
                // Set the OTP expiration time
                var otpExpirationTime =
                    @if (request()->has('otpExpirationTime'))
                        {{ urldecode(request('otpExpirationTime')) }}
                    @endif ;

                // Update the countdown clock every second
                var countdown = setInterval(function() {
                    // Get the current time
                    var now = Math.floor(Date.now() / 1000);

                    // Calculate the remaining time
                    var remainingTime = otpExpirationTime - now;

                    // If time is up, display a message and clear the countdown interval
                    if (remainingTime <= 0) {
                        document.getElementById('countdown').innerHTML = 'OTP expired';
                        document.getElementById('resendOTPForm').style.display = 'block';
                        clearInterval(countdown);
                    } else {
                        // Calculate remaining minutes and seconds
                        var minutes = Math.floor(remainingTime / 60);
                        var seconds = remainingTime % 60;

                        document.getElementById('resendOTPForm').style.display = 'none';


                        // Display the remaining time
                        document.getElementById('countdown').innerHTML = 'Time remaining : ' + minutes + 'm ' + seconds +
                            's';
                    }
                }, 1000); // Update every second
            </script>

            <div class="div300" style="width: 400px; text-align: center;">
                <iframe src="https://lottie.host/embed/46f26792-79f1-46b5-9e0a-14391897bb34/0TCi5OsNhz.json"></iframe>
            </div>

            <div
                style="background-color: #d4edda; color: #155724; border-color: #c3e6cb; padding: .75rem 1.25rem; margin-bottom: 1rem; border: 1px solid transparent; border-radius: .25rem; font-size: 1.3rem; text-align: center;">
                {{ urldecode(request('verifymessage')) }}

            </div>

            <form action="{{ route('verify.email') }}" method="post" id="verifyForm">
                @csrf
                {{-- <div class="div300" style="width: 360px; text-align: center;margin-bottom:10px">
                    <label for="newrequest" style="font-size: 15px; display: block;line-height: 2.7rem;">If you still need to
                        verify your email, click the button below to request another verification email.</label> <br>
                    
                </div> --}}

                <div style="text-align: center;">
                    <input type="number" name="otpcode" id="otpcode" placeholder="Enter OTP here">
                    <button type="submit" id="verifyButton"
                        style="display: inline-block; padding: 10px 20px; background-color: #113163; color: #fff; text-decoration: none; border-radius: 5px;font-size:14px;margin-top:10px;cursor: pointer;margin-bottom:10px;">
                        Verify Now <button>
                </div>

                <script>
                    // Get the form and input element
                    var verifyForm = document.getElementById('verifyForm');
                    var otpInput = document.getElementById('otpcode');
                    var verifyButton = document.getElementById('verifyButton');

                    // Add event listener to the form for submit event
                    verifyForm.addEventListener('submit', function(event) {
                        // Check if the input value is empty
                        if (otpInput.value.trim() === '') {
                            // Prevent the form submission
                            event.preventDefault();
                            // Optionally, you can display an error message or perform other actions
                            alert('Please enter the OTP code.');
                        }
                    });
                </script>

            </form>

            <!-- Button back to home -->
            <div style="text-align: center;">

                <form action="{{ route('resendVerificationEmail') }}" method="post" id="resendOTPForm">
                    @csrf
                    <input type="hidden" name="email"
                        value="@if (request()->has('email')) {{ urldecode(request('email')) }} @endif">

                    <button type="submit"
                        style="display: inline-block; padding: 5px 5px;color: #2654ee; text-decoration: none; font-size:14px;margin-top:10px;cursor: pointer;">Resend
                        New OTP </button>

                </form>

            </div>


            <!-- Button back to home -->
            <div style="text-align: center;">
                <a href="https://conqueror.ae/"
                    style="display: inline-block; padding: 10px 20px; background-color: #0f0f0f; color: #fff; text-decoration: none; border-radius: 5px;font-size:14px;margin-top:10px;">Back
                    to Home</a>
            </div>

        </section>
    @endif
@endsection
