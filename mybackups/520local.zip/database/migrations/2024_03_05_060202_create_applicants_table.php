<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('applicants', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('position_id'); // Change to unsignedBigInteger
            $table->string('nationality');
            $table->string('first_name');
            $table->string('last_name');
            $table->string('mother_name');
            $table->string('nid_cnic_front')->nullable();
            $table->string('nid_cnic_back')->nullable();
            $table->string('uaeresident')->nullable();
            $table->string('emiratesid')->nullable();
            $table->string('date_of_birth');
            $table->string('contact_number');
            $table->string('whatsapp_number');
            $table->string('email');
            $table->string('applicant_image');
            $table->string('applicant_passport');
            $table->string('passportno');
            $table->string('date_of_expiry');
            $table->string('applicant_resume')->nullable();
            $table->string('appli_dri_number')->nullable();
            $table->string('specialpage')->nullable();
            $table->string('appli_dri_lisence_frontpart')->nullable();
            $table->string('appli_dri_lisence_backpart')->nullable();
            $table->string('submissionid')->nullable();
            $table->string('otp')->nullable();
            $table->boolean('otp_verified')->default(false);
            $table->timestamp('otp_generated_at')->nullable();
            $table->string('applicant_status')->nullable();
            $table->enum('applicant_status', ['new_entry', 'checked', 'editted', 'invited','called','hired', 'accepted', 'rejected', 'under_review', 'shortlisted', 'pending', 'offer_extended', 'offer_accepted', 'offer_declined', 'reschedule_requested'])->default('new_entry');
            $table->boolean('viewed')->default(false);
            $table->string('reference')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('applicants');
    }
};
