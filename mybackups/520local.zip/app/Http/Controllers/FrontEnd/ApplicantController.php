<?php

namespace App\Http\Controllers\FrontEnd;

use App\Models\Applicant;
use App\Models\JobPosition;
use Illuminate\Http\Request;
use App\Mail\ApplicantVerifyOTP;
use App\Http\Controllers\Controller;
use App\Models\Interview;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Storage;

class ApplicantController extends Controller
{
    // Display a listing of the applicants.
    public function index()
    {
        $applicants = Applicant::orderBy('created_at', 'desc')->get();
        return view('layouts.admin.job-applicants.index', compact('applicants'));
    }

    public function indexverified()
    {
        $applicants = Applicant::where('otp_verified', 1)
            ->orderBy('created_at', 'desc')
            ->get();

        return view('layouts.admin.job-applicants.indexverified', compact('applicants'));
    }

    public function notverified()
    {
        $applicants = Applicant::where('otp_verified', 0)
            ->orderBy('created_at', 'desc')
            ->get();
        return view('layouts.admin.job-applicants.indexnotverified', compact('applicants'));
    }

    public function invited()
    {
        $applicants = Applicant::where('applicant_status', 'invited')
            ->orderBy('created_at', 'desc')
            ->get();
        return view('layouts.admin.job-applicants.indexinvited', compact('applicants'));
    }

    public function hired()
    {
        $applicants = Applicant::where('applicant_status', 'hired')
            ->orderBy('created_at', 'desc')
            ->get();
        return view('layouts.admin.job-applicants.indexhired', compact('applicants'));
    }


    public function store(Request $request)
    {

     //   return $request;


        $this->validate($request, [
            'position_id' => 'required',
            'nationality' => 'required',
            'first_name' => 'required',
            'last_name' => 'required',
            'mother_name' => 'required',
            'nid_cnic_front' => 'nullable',
            'nid_cnic_back' => 'nullable',
            'uaeresident' => 'nullable',
            'emiratesid' => 'nullable',
            'date_of_birth' => 'required',
            'contact_number' => 'required',
            'whatsapp_number' => 'required',
            'email' => 'required|email|unique:applicants,email',
            'applicant_image' => 'required|max:300',
            'applicant_passport' => 'required|max:1000',
            'passportno' => 'required',
            'date_of_expiry' => 'required',
            'applicant_resume' => 'nullable|max:1000',
            'appli_dri_number' => 'nullable|max:1000',
            'specialpage' => 'nullable',
            'appli_dri_lisence_frontpart' => 'nullable|max:500',
            'appli_dri_lisence_backpart' => 'nullable|max:500',
            'reference' => 'nullable',
        ]);

        // Upload and save the files
        $imageName1 = $request->hasFile('applicant_image') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_image.' . $request->applicant_image->extension() : null;

        $imageName2 = $request->hasFile('applicant_passport') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_passport.' . $request->applicant_passport->extension() : null;

        $imageName3 = $request->hasFile('applicant_resume') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_resume.' . $request->applicant_resume->extension() : null;

        $imageName4 = $request->hasFile('appli_dri_lisence_frontpart') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_driving_lisence_front.' . $request->appli_dri_lisence_frontpart->extension() : null;

        $imageName5 = $request->hasFile('appli_dri_lisence_backpart') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_driving_lisence_back.' . $request->appli_dri_lisence_backpart->extension() : null;

        $imageName6 = $request->hasFile('specialpage') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_specialpage.' . $request->specialpage->extension() : null;

        $imageName7 = $request->hasFile('nid_cnic_front') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_nid_cnic_front.' . $request->nid_cnic_front->extension() : null;

        $imageName8 = $request->hasFile('nid_cnic_back') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_nid_cnic_back.' . $request->nid_cnic_back->extension() : null;

        //Move and save each uploaded file with a unique filename
        if ($imageName1) {
            $request->applicant_image->move(public_path('applicants'), $imageName1);
        }
        if ($imageName2) {
            $request->applicant_passport->move(public_path('applicants'), $imageName2);
        }
        if ($imageName3) {
            $request->applicant_resume->move(public_path('applicants'), $imageName3);
        }
        if ($imageName4) {
            $request->appli_dri_lisence_frontpart->move(public_path('applicants'), $imageName4);
        }
        if ($imageName5) {
            $request->appli_dri_lisence_backpart->move(public_path('applicants'), $imageName5);
        }
        if ($imageName6) {
            $request->specialpage->move(public_path('applicants'), $imageName6);
        }
        if ($imageName7) {
            $request->nid_cnic_front->move(public_path('applicants'), $imageName7);
        }
        if ($imageName8) {
            $request->nid_cnic_back->move(public_path('applicants'), $imageName8);
        }

        // Create a new Applicant instance
        $applicants = new Applicant();

        // Function to generate random letters
        function generateRandomLetters($length)
        {
            $letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            return substr(str_shuffle($letters), 0, $length);
        }

        // Generate random letters
        $letters = generateRandomLetters(3);

        // Generatesubmission id
        $numbers = mt_rand(1000000, 9999999);

        // Generate OTP
        $otp = mt_rand(100000, 999999);

        // Record the time when OTP is generated
        $otpGeneratedTime = now();

        // Concatenate letters and numbers to form submission ID
        $submissionid = $letters . $numbers;

        // Assign form input values and uploaded file names
        $applicants->position_id = $request->position_id;
        $applicants->nationality = $request->nationality;
        $applicants->first_name = $request->first_name;
        $applicants->last_name = $request->last_name;
        $applicants->mother_name = $request->mother_name;
        $applicants->uaeresident = $request->has('uaeresident') ? 1 : 0; // Assigning the status based on checkbox state
        $applicants->emiratesid = $request->emiratesid;
        $applicants->date_of_birth = $request->date_of_birth;
        $applicants->contact_number = $request->contact_number;
        $applicants->whatsapp_number = $request->whatsapp_number;
        $applicants->email = $request->email;
        $applicants->appli_dri_number = $request->appli_dri_number;

        $applicants->applicant_image = $imageName1;
        $applicants->applicant_passport = $imageName2;
        $applicants->passportno = $request->passportno;
        $applicants->date_of_expiry = $request->date_of_expiry;
        $applicants->applicant_resume = $imageName3;
        $applicants->specialpage = $imageName6;
        $applicants->nid_cnic_front = $imageName7;
        $applicants->nid_cnic_back = $imageName8;
        $applicants->appli_dri_lisence_frontpart = $imageName4;
        $applicants->appli_dri_lisence_backpart = $imageName5;
        $applicants->submissionid = $submissionid;
        $applicants->otp = $otp;
        $applicants->otp_generated_at = $otpGeneratedTime;
        $applicants->reference = $request->reference;


        // Save the Applicant instance
        $applicants->save();

        Mail::to($applicants->email)->send(new ApplicantVerifyOTP($applicants->first_name, $applicants->last_name, $applicants->email, $otp));

        // Calculate OTP expiration time
        $otpExpirationTime = $otpGeneratedTime->addMinutes(5)->timestamp;

        // Encode OTP expiration time for URL
        $encodedExpirationTime = urlencode($otpExpirationTime);

        // return redirect('/verified')->with('verifymessage', 'Your application has been successfully submitted. Welcome to Conqueror Services, Dubai. You will get a call from our recruitment team within 7-14 days for an interview in your home country.');


        // Pass necessary data to the view
        return redirect('/verify-now?verifymessage=' . urlencode('An OTP code has been sent to your email address. Please verify your email before completing the job application.') . '&email=' . urlencode($applicants->email) . '&otpExpirationTime=' . $encodedExpirationTime);
    }

    // Display the specified applicant.
    public function show(Applicant $id)
    {
        $applicant = $id;

        // Find the previous applicant
        $previousApplicant = Applicant::where('id', '<', $applicant->id)->latest()->first();

        // Find the next applicant
        $nextApplicant = Applicant::where('id', '>', $applicant->id)->oldest()->first();

        // Find the first applicant
        $firstApplicant = Applicant::oldest()->first();

        // Find the last applicant
        $lastApplicant = Applicant::latest()->first();

        // Mark the application as viewed
        $applicant->viewed = true;
        $applicant->save();

        $interviewdata = Interview::where('applicant_id', $applicant->id)->first();


        return view('layouts.admin.job-applicants.view', compact('applicant', 'previousApplicant', 'nextApplicant', 'firstApplicant', 'lastApplicant', 'interviewdata'));
    }

    // Show the form for editing the specified applicant.
    public function editappli($id)
    {

        // return $id;
        $applicant = Applicant::findOrFail($id);
        // $allpositions = JobPosition::findOrFail($id);

        return view('layouts.admin.job-applicants.edit', compact('applicant'));
    }

    // Update the specified applicant in storage.
    public function update(Request $request, $id)
    {

        $applicant = Applicant::findOrFail($id);

        // dd($request->specialpage);

        // Validate the request data
        $validatedData = $request->validate([
            'position_id' => 'required',
            'nationality' => 'required',
            'first_name' => 'required',
            'last_name' => 'required',
            'mother_name' => 'nullable',
            'nid_cnic_front' => 'nullable',
            'nid_cnic_back' => 'nullable',
            'uaeresident' => 'nullable',
            'emiratesid' => 'nullable',
            'date_of_birth' => 'required',
            'contact_number' => 'required',
            'whatsapp_number' => 'required',
            'email' => 'required|email|unique:applicants,email,' . $applicant->id,
            'applicant_image' => 'nullable|max:300',
            'applicant_passport' => 'nullable|max:1000',
            'passportno' => 'required',
            'date_of_expiry' => 'required',
            'applicant_resume' => 'nullable|max:1000',
            'appli_dri_number' => 'nullable|max:1000',
            'specialpage' => 'nullable',
            'appli_dri_lisence_frontpart' => 'nullable|max:500',
            'appli_dri_lisence_backpart' => 'nullable|max:500',
            'reference' => 'nullable',
        ]);



        // Applicant image
        $applicant_image_file = $request->hasFile('applicant_image') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_image.' . $request->applicant_image->extension() : $applicant->applicant_image;
        if ($request->hasFile('applicant_image')) {
            if ($applicant->applicant_image) {
                File::delete(public_path('applicants/' . $applicant->applicant_image));
            }
            $request->applicant_image->move(public_path('applicants'), $applicant_image_file);
        }

        $applicant->applicant_image = $applicant_image_file;

        // Applicant Passport
        $applicant_passport_file = $request->hasFile('applicant_passport') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_passport.' . $request->applicant_passport->extension() : $applicant->applicant_passport;
        if ($request->hasFile('applicant_passport')) {
            if ($applicant->applicant_passport) {
                File::delete(public_path('applicants/' . $applicant->applicant_passport));
            }
            $request->applicant_passport->move(public_path('applicants'), $applicant_passport_file);
        }
        $applicant->applicant_passport = $applicant_passport_file;


        // Applicant Special Page
        $specialpage_file = $request->hasFile('specialpage') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_specialpage.' . $request->specialpage->extension() : $applicant->specialpage;
        if ($request->hasFile('specialpage')) {
            if ($applicant->specialpage) {
                File::delete(public_path('applicants/' . $applicant->specialpage));
            }
            $request->specialpage->move(public_path('applicants'), $specialpage_file);
        }

        $applicant->specialpage = $specialpage_file;


        // Applicant resume
        $applicant_resume_file = $request->hasFile('applicant_resume') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_resume.' . $request->applicant_resume->extension() : $applicant->applicant_resume;
        if ($request->hasFile('applicant_resume')) {
            if ($applicant->applicant_resume) {
                File::delete(public_path('applicants/' . $applicant->applicant_passport));
            }
            $request->applicant_resume->move(public_path('applicants'), $applicant_resume_file);
        }
        $applicant->applicant_resume = $applicant_resume_file;


        // Applicant dri_lisence_frontpart
        $appli_dri_lisence_frontpart_file = $request->hasFile('appli_dri_lisence_frontpart') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_resume.' . $request->appli_dri_lisence_frontpart->extension() : $applicant->appli_dri_lisence_frontpart;
        if ($request->hasFile('appli_dri_lisence_frontpart')) {
            if ($applicant->appli_dri_lisence_frontpart) {
                File::delete(public_path('applicants/' . $applicant->appli_dri_lisence_frontpart));
            }
            $request->appli_dri_lisence_frontpart->move(public_path('applicants'), $appli_dri_lisence_frontpart_file);
        }
        $applicant->appli_dri_lisence_frontpart = $appli_dri_lisence_frontpart_file;


        // Applicant dri_lisence_backpart
        $appli_dri_lisence_backpart_file = $request->hasFile('appli_dri_lisence_backpart') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_dri_lisence_backpart.' . $request->appli_dri_lisence_backpart->extension() : $applicant->appli_dri_lisence_backpart;
        if ($request->hasFile('appli_dri_lisence_backpart')) {
            if ($applicant->appli_dri_lisence_backpart) {
                File::delete(public_path('applicants/' . $applicant->appli_dri_lisence_backpart));
            }
            $request->appli_dri_lisence_backpart->move(public_path('applicants'), $appli_dri_lisence_backpart_file);
        }
        $applicant->appli_dri_lisence_backpart = $appli_dri_lisence_backpart_file;

        // Applicant nid_cnic_front
        $nid_cnic_front_file = $request->hasFile('nid_cnic_front') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_nid_cnic_front.' . $request->nid_cnic_front->extension() : $applicant->nid_cnic_front;
        if ($request->hasFile('nid_cnic_front')) {
            if ($applicant->nid_cnic_front) {
                File::delete(public_path('applicants/' . $applicant->nid_cnic_front));
            }
            $request->nid_cnic_front->move(public_path('applicants'), $nid_cnic_front_file);
        }
        $applicant->nid_cnic_front = $nid_cnic_front_file;

        // Applicant nid_cnic_back
        $nid_cnic_back_file = $request->hasFile('nid_cnic_back') ? str_replace(' ', '_', $request->first_name) . '_' . time() . '_nid_cnic_back.' . $request->nid_cnic_back->extension() : $applicant->nid_cnic_back;
        if ($request->hasFile('nid_cnic_back')) {
            if ($applicant->nid_cnic_back) {
                File::delete(public_path('applicants/' . $applicant->nid_cnic_back));
            }
            $request->nid_cnic_back->move(public_path('applicants'), $nid_cnic_back_file);
        }
        $applicant->nid_cnic_back = $nid_cnic_back_file;


        // Update the Applicant instance with the new data
        $applicant->position_id = $validatedData['position_id'];
        $applicant->nationality = $validatedData['nationality'];
        $applicant->first_name = $validatedData['first_name'];
        $applicant->last_name = $validatedData['last_name'];
        $applicant->mother_name = $validatedData['mother_name'];
        $applicant->uaeresident = $request->has('uaeresident') ? 1 : 0;
        $applicant->emiratesid = $validatedData['emiratesid'];
        $applicant->date_of_birth = $validatedData['date_of_birth'];
        $applicant->contact_number = $validatedData['contact_number'];
        $applicant->whatsapp_number = $validatedData['whatsapp_number'];
        $applicant->email = $validatedData['email'];
        $applicant->appli_dri_number = $validatedData['appli_dri_number'];
        $applicant->passportno = $validatedData['passportno'];
        $applicant->date_of_expiry = $validatedData['date_of_expiry'];
        $applicant->reference = $validatedData['reference'];

        // Save the updated Applicant instance
        $applicant->save();

        // Redirect or return a response
        return redirect()->back()->with('success', 'Applicant data updated successfully.');
    }

    // Verify email from admi panek
    public function verifyemailadmin($id)
    {
        $getApplicant = Applicant::findorfail($id);
        if ($getApplicant->otp_verified == 0) {
            $otp = mt_rand(100000, 999999);
            $otpGeneratedTime = now();
            $getApplicant->otp = $otp;
            $getApplicant->otp_generated_at = $otpGeneratedTime;
            $getApplicant->save();
            Mail::to($getApplicant->email)->send(new ApplicantVerifyOTP($getApplicant->first_name, $getApplicant->last_name, $getApplicant->email, $otp));
            return redirect()->back()->with('otpstatus', 'Email Verificaon OTP Sent to Applicant');
        } else {
            return redirect()->back()->with('message', 'User Verified');
        }
    }

    public function verifyemailadminotp(Request $request)
    {
        // Retrieve the OTP from the request
        $otp = $request->input('otpcode');

        // Retrieve the applicant with the provided OTP
        $applicant = Applicant::where('otp', $otp)->first();

        // Check if an applicant with the provided OTP exists
        if ($applicant) {
            // Update otp_verified column to 1
            $applicant->otp_verified = 1;
            // Save the changes to the database
            $applicant->save();
            return response()->json(['message' => 'OTP verified successfully', 'otp' => $otp, 'mainotp' => $applicant->otp], 200);
        } else {
            return response()->json(['message' => 'OTP Wrong', 'otp' => $otp], 200);
        }
    }


    public function destroy($id)
    {
        // Find the job position by ID and delete it
        $applicant = Applicant::findOrFail($id);

        // Delete the associated files if they exist
        $filesToDelete = [];
        if ($applicant->applicant_image) {
            $filesToDelete[] = public_path('applicants/' . $applicant->applicant_image);
        }
        if ($applicant->applicant_passport) {
            $filesToDelete[] = public_path('applicants/' . $applicant->applicant_passport);
        }
        if ($applicant->applicant_resume) {
            $filesToDelete[] = public_path('applicants/' . $applicant->applicant_resume);
        }
        if ($applicant->appli_dri_lisence_frontpart) {
            $filesToDelete[] = public_path('applicants/' . $applicant->appli_dri_lisence_frontpart);
        }
        if ($applicant->appli_dri_lisence_backpart) {
            $filesToDelete[] = public_path('applicants/' . $applicant->appli_dri_lisence_backpart);
        }

        // Delete the files
        File::delete($filesToDelete);

        $applicant->delete();

        // Redirect back to the index page with a success message
        return redirect()->back()->with('success', 'Applicant deleted successfully.');
    }

    // Update applicant status
    public function updateStatus(Request $request, $id)
    {
        $applicant = Applicant::findOrFail($id);
        $applicant->applicant_status = $request->status;
        $applicant->save();

        return redirect()->back()->with('success', 'Applicant status updated successfully');
    }
}
