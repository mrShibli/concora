<?php

namespace App\Http\Controllers\Admin;

use Carbon\Carbon;
use App\Models\User;
use App\Mail\Demomail;
use App\Models\Contact;
use App\Models\Applicant;
use App\Models\Quotation;
use App\Models\JobPosition;
use Illuminate\Http\Request;
use App\Mail\ApplicantVerifyOTP;
use App\Models\EmailVerification;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use App\Mail\JobApplicationVerification;
use App\Models\Weather; // Assuming your Weather model namespace is App\Models\Weather

class DashboardController extends Controller
{
    public function editappli() {

        return 'hi';
        
    }

    public function verifyjobmail(Request $request)
    {
        // Get the fname and email from the request URL parameters
        $fname = $request->query('fname');
        $email = $request->query('email');

        // Validate email address
        $request->validate([
            'email' => 'required|email',
            // Other form validation rules
        ]);

        // Generate unique token for email verification
        $token = sha1(uniqid());

        // Save token in database (you might want to create a table for this)
        // Example:
        DB::table('email_verifications')->insert([
            'email' => $email,
            'token' => $token,
            'created_at' => now(),
        ]);

        $jobmaildata = [
            'email' => $email,
            'fname' => $fname,
            'token' => $token,
        ];

        // Send email verification link
        Mail::to($email)->send(new JobApplicationVerification($jobmaildata));

        return redirect('/verify-now')->with('verifymessage', 'An email verification link has been sent to your email address. Please verify your email before completing the job application.');
    }

    public function verifyNow()
    {
        return view('layouts.frontend.verifynow');
    }

    public function errorVerification(Request $request)
    {
        // Get the email from the request URL parameters
        $email = $request->session()->get('email');
        return view('layouts.frontend.errorverify', compact('email'));
    }

    public function resendVerificationEmail(Request $request)
    {
        // Retrieve email address from the request
        $email = $request->email;

        // Find the verification record associated with the email address
        $verificationRecord = Applicant::where('email', $email)
            ->where('otp_verified', 0)
            ->first();

        // Check if a verification record exists for the email address
        if ($verificationRecord) {
            // Generate a new otp
            // Generate OTP
            $otp = mt_rand(100000, 999999);

            // Update the verification record with the new token and current timestamp
            $verificationRecord->update([
                'otp' => $otp,
                'otp_generated_at' => now(),
            ]);

            // Send the verification email
            // Assuming you have a method to send the verification email
            // Example: Mail::to($email)->send(new VerificationEmail($newToken));

            $getApplicant = Applicant::where('email', $email)->first();


            Mail::to($getApplicant->email)->send(new ApplicantVerifyOTP($getApplicant->first_name, $getApplicant->last_name, $getApplicant->email, $otp));

            $otpGeneratedTime = now();

            // Calculate OTP expiration time
            $otpExpirationTime = $otpGeneratedTime->addMinutes(5)->timestamp;

            // Encode OTP expiration time for URL
            $encodedExpirationTime = urlencode($otpExpirationTime);

            // Redirect back with a success message
            return redirect('/verify-now?verifymessage=' . urlencode('An OTP code has been sent to your email address. Please verify your email before completing the job application.') . '&email=' . urlencode($getApplicant->email) . '&otpExpirationTime=' . $encodedExpirationTime);
        } else {

            // Handle case when no verification record is found for the email address
            $getApplicant = Applicant::where('email', $email)->first();
            return redirect('/verify-now?verifymessage=' . urlencode('No verification record found for the email address.') . '&email=' . urlencode($getApplicant->email));
        }
    }

    public function verified()
    {
        return view('layouts.frontend.verified');
    }

    public function verifyEmail(Request $request)
    {

        $getotpcode = $request->otpcode;

        // Retrieve email verification record from the database
        $verificationRecord = Applicant::where('otp', $getotpcode)->first();

        // Check if a record with the provided token exists
        if (!$verificationRecord) {
            // Handle case when token is not found
            return redirect('/error-verification')->with('error', 'Invalid verification link.');
        }

        // Check if token has expired (more than 3 minutes have passed)
        $tokenGeneratedTime = Carbon::parse($verificationRecord->otp_generated_at);
        $currentTime = now();
        $tokenExpirationTime = $tokenGeneratedTime->addMinutes(5);


        if ($currentTime->gt($tokenExpirationTime)) {
            // Token has expired, handle accordingly
            return redirect('/error-verification')->with('error', 'Verification code has expired. Please request a new one.')->with('email', $verificationRecord->email);
        }

        // Mark email as verified in your database
        $verificationRecord->update(['otp_verified' => 1]);

        // Redirect user to a confirmation page
        return redirect('/verified')->with('verifymessage', 'Your email has been successfully verified. Welcome to Conqueror Services, Dubai. You will get a call from our recruitment team within 7-14 days for an interview in your home country.');
    }

    public function sendmail()
    {
        $maildata = [
            'title' => 'Mail Testing',
            'message' => 'Email Testing message'
        ];

        Mail::to('uaeconquerorllc@gmail.com')->send(new Demomail($maildata));
        return redirect('/')->with('message', 'Mailsubmitted');
    }

    //Main Page
    public function index()
    {
        $JobApplicant = Applicant::count();
        $quotation = Quotation::count();
        $contactscount = Contact::count();
        $jobpositions = JobPosition::count();

        $JobApplicantOtpVerified = Applicant::where('otp_verified', 1)->count();
        $JobApplicantOtpNotVerified = Applicant::where('otp_verified', 0)->count();
        $JobApplicantInvited = Applicant::where('applicant_status', 'invited')->count();
        $JobApplicantHired = Applicant::where('applicant_status', 'hired')->count();

        $applicants = Applicant::orderBy('created_at', 'desc')->take(25)->get();
        return view('layouts.admin.dashboard', compact('JobApplicant', 'quotation', 'jobpositions', 'contactscount', 'applicants', 'JobApplicantOtpVerified', 'JobApplicantOtpNotVerified', 'JobApplicantInvited', 'JobApplicantHired'));
    }

    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
