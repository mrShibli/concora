<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>CONQUEROR Admin</title>

    <!-- plugins:css -->
    <link rel="stylesheet" href="{{ asset('vendors/feather/feather.css') }}">
    <link rel="stylesheet" href="{{ asset('vendors/ti-icons/css/themify-icons.css') }}">
    <link rel="stylesheet" href="{{ asset('vendors/css/vendor.bundle.base.css') }}">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="{{ asset('vendors/datatables.net-bs4/dataTables.bootstrap4.css') }}">
    <link rel="stylesheet" href="{{ asset('vendors/ti-icons/css/themify-icons.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('js/select.dataTables.min.css') }}">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="{{ asset('css/vertical-layout-light/style.css') }}">
    <link rel="stylesheet" href="{{ asset('css/vertical-layout-light/style.css') }}">
    <!-- endinject -->
    <link rel="shortcut icon" href="{{ asset('frontend/images/favicon.png') }}" />

    {{-- <link rel="stylesheet" href="https://cdn.datatables.net/2.0.1/css/dataTables.dataTables.css" /> --}}

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha384-RhhP8HfE8udcrPcX/lGgGqqM0w//m05MyyO3nFL6jUZjIDFDzHq3fFyJqHqImWrw" crossorigin="anonymous">

    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.css">

    <!-- SweetAlert2 JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    @yield('styles')
    <style>
        .dlogo {
            background: #506B96C4;
            padding: 5px;
            border-radius: 7px;
        }

        button.logutbutton {
            background: none;
        }

        .dbtn {

            border: none;
            padding: 0;
            margin: 0;
            background: none;
        }


        .jsgrid,
        .table td,
        .jsgrid .jsgrid-table td {
            padding: 0.20rem 0.40rem !important;
        }

        .table th {
            padding: 0.60rem 0.54rem !important;
        }

        .content-wrapper {
            padding: 0.7rem !important;
        }

        div#settings-trigger {
            display: none;
        }

        .bactive a {
            color: grey;
        }

        .dropdown .dropdown-toggle:after {
            display: none;
        }

        .viewdetialsbtn a.btn {
            border-radius: 7px !important;
        }

        .inpersonmodal .form-group {
            margin-bottom: 11px;
        }

        .viewed {
            background-color: #ffffff;
        }
        .notviewed {
            background-color: #f0f0f0;
        }
    </style>
</head>

<body>

    <div class="container-scroller">

        <!-- partial:partials/_navbar.html -->
        <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
            <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
                @auth
                    @if (Auth::user()->role == 1)
                        <a class="navbar-brand brand-logo mr-5 dlogo" href="{{ route('dashboard') }}"><img
                                src="{{ asset('images/adminlogo.png') }}" class="mr-2" alt="logo" /></a>
                        <a class="navbar-brand brand-logo-mini" href="{{ route('dashboard') }}"><img
                                src="{{ asset('frontend/images/conqueror-logo.png') }}" alt="logo" /></a>
                    @elseif(Auth::user()->role == 2)
                        <a class="navbar-brand brand-logo mr-5 dlogo" href="{{ route('frontdesk.index') }}"><img
                                src="{{ asset('images/adminlogo.png') }}" class="mr-2" alt="logo" /></a>
                        <a class="navbar-brand brand-logo-mini" href="{{ route('frontdesk.index') }}"><img
                                src="{{ asset('frontend/images/conqueror-logo.png') }}" alt="logo" /></a>
                    @endif
                @endauth

            </div>
            <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
                <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
                    <span class="icon-menu"></span>
                </button>
                <ul class="navbar-nav mr-lg-2">
                    <li class="nav-item nav-search d-none d-lg-block">
                        <div class="input-group">
                            <div class="input-group-prepend hover-cursor" id="navbar-search-icon">
                                <span class="input-group-text" id="search">
                                    <i class="icon-search"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" id="navbar-search-input" placeholder="Search now"
                                aria-label="search" aria-describedby="search">
                        </div>
                    </li>
                </ul>
                <ul class="navbar-nav navbar-nav-right">
                    <li class="nav-item dropdown">
                        <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#"
                            data-toggle="dropdown">
                            <i class="icon-bell mx-0"></i>
                            <span class="count"></span>
                        </a>
                    </li>
                    <li class="nav-item nav-profile dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
                            <img src="{{ asset('images/faces/face28.jpg') }}" alt="profile" />
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown"
                            aria-labelledby="profileDropdown">
                            <a class="dropdown-item">
                                <i class="ti-settings text-primary"></i>
                                Settings
                            </a>
                            <a class="dropdown-item">


                                <form action="{{ route('logout') }}" method="POST">
                                    @csrf
                                    <button type="submit" class="logutbutton" style="border: none; padding:0;"><i
                                            class="ti-power-off text-primary"></i>Logout</button>
                                </form>
                            </a>
                        </div>
                    </li>
                    <li class="nav-item nav-settings d-none d-lg-flex">
                        <a class="nav-link" href="#">
                            <i class="icon-ellipsis"></i>
                        </a>
                    </li>
                </ul>
                <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
                    data-toggle="offcanvas">
                    <span class="icon-menu"></span>
                </button>
            </div>
        </nav>

        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_settings-panel.html -->
            <div class="theme-setting-wrapper">
                <div id="settings-trigger"><i class="ti-settings"></i></div>
                <div id="theme-settings" class="settings-panel">
                    <i class="settings-close ti-close"></i>
                    <p class="settings-heading">SIDEBAR SKINS</p>
                    <div class="sidebar-bg-options selected" id="sidebar-light-theme">
                        <div class="img-ss rounded-circle bg-light border mr-3"></div>Light
                    </div>
                    <div class="sidebar-bg-options" id="sidebar-dark-theme">
                        <div class="img-ss rounded-circle bg-dark border mr-3"></div>Dark
                    </div>
                    <p class="settings-heading mt-2">HEADER SKINS</p>
                    <div class="color-tiles mx-0 px-4">
                        <div class="tiles success"></div>
                        <div class="tiles warning"></div>
                        <div class="tiles danger"></div>
                        <div class="tiles info"></div>
                        <div class="tiles dark"></div>
                        <div class="tiles default"></div>
                    </div>
                </div>
            </div>

            <nav class="sidebar sidebar-offcanvas" id="sidebar">

                <ul class="nav">
                    @auth
                        @if (in_array(Auth::user()->role, ['super_admin', 'group_admin', 'admin']))
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('dashboard') }}">
                                    <i class="icon-grid menu-icon"></i>
                                    <span class="menu-title">Dashboard</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="collapse" href="#job-board" aria-expanded="false"
                                    aria-controls="job-board">
                                    <i class="icon-layout menu-icon"></i>
                                    <span class="menu-title">Job Board</span>
                                    <i class="menu-arrow"></i>
                                </a>
                                <div class="collapse" id="job-board">
                                    <ul class="nav flex-column sub-menu">
                                        <li class="nav-item"> <a class="nav-link"
                                                href="{{ Route('applicants.index') }}">Job
                                                Applicants</a></li>
                                        <li class="nav-item"> <a class="nav-link"
                                                href="{{ route('job_positions.index') }}">All Positions</a></li>
                                        <li class="nav-item"> <a class="nav-link"
                                                href="{{ route('job_positions.create') }}">Add Positions</a></li>
                                    </ul>
                                </div>
                            </li>

                            <!-- Users Menu Item -->
                            <li class="nav-item {{ request()->is('admin/users*') ? 'active' : '' }}">
                                <a class="nav-link" data-toggle="collapse" href="#menu-user" aria-expanded="false"
                                    aria-controls="menu-user">
                                    <i class="icon-menu menu-icon"></i>
                                    <span class="menu-title">Users</span>
                                    <i class="menu-arrow"></i>
                                </a>
                                <!-- Users Submenu -->
                                <div class="collapse" id="menu-user">
                                    <ul class="nav flex-column sub-menu">
                                        <li class="nav-item"> <a class="nav-link"
                                                href="{{ route('admin.users.index') }}">All Users</a></li>
                                        <li class="nav-item"> <a class="nav-link"
                                                href="{{ route('admin.users.create') }}">Add User</a></li>
                                    </ul>
                                </div>
                            </li>





                            <!-- website settings section  -->

                            <li class="nav-item">
                                <a class="nav-link" data-toggle="collapse" href="#website-settings"
                                    aria-expanded="false" aria-controls="website-settings">
                                    <i class="icon-bar-graph menu-icon"></i>
                                    <span class="menu-title">Website Settings</span>
                                    <i class="menu-arrow"></i>
                                </a>
                                <div class="collapse" id="website-settings">
                                    <ul class="nav flex-column sub-menu">
                                        <li class="nav-item"> <a class="nav-link" href="#">Website Settings</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" data-toggle="collapse" href="#slider-settings" aria-expanded="false"
                                    aria-controls="slider-settings">
                                    <i class="icon-grid-2 menu-icon"></i>
                                    <span class="menu-title">Slider Settings</span>
                                    <i class="menu-arrow"></i>
                                </a>
                                <div class="collapse" id="slider-settings">
                                    <ul class="nav flex-column sub-menu">
                                        <li class="nav-item"> <a class="nav-link" href="#">All Sliders</a></li>
                                    </ul>
                                </div>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('admin.contact') }}">
                                    <i class="icon-paper menu-icon"></i>
                                    <span class="menu-title">Contacts</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('qauotation.index') }}">
                                    <i class="icon-head menu-icon"></i>
                                    <span class="menu-title">Qauotations</span>
                                </a>
                            </li>
                        @endif

                        @if (Auth::user()->role == 'manager')
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="collapse" href="#job-board" aria-expanded="false"
                                    aria-controls="job-board">
                                    <i class="icon-layout menu-icon"></i>
                                    <span class="menu-title">Job Board</span>
                                    <i class="menu-arrow"></i>
                                </a>
                                <div class="collapse" id="job-board">
                                    <ul class="nav flex-column sub-menu">
                                        <li class="nav-item"> <a class="nav-link"
                                                href="{{ Route('applicants.index') }}">Job
                                                Applicants</a></li>

                                    </ul>
                                </div>
                            </li>
                        @endif


                    @endauth
                </ul>
            </nav>

            <!-- partial -->

            <div class="main-panel">


                @yield('content')

                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <footer class="footer">
                    <div class="d-sm-flex justify-content-center justify-content-sm-between">
                        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2024.

                            CONQUEROR SERVICES LLC
                            . All rights reserved.</span>
                        </span>
                    </div>
                </footer>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->

        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->

    <!-- plugins:js -->
    <script src="{{ asset('vendors/js/vendor.bundle.base.js') }}"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="{{ asset('vendors/chart.js/Chart.min.js') }}"></script>
    <script src="{{ asset('vendors/datatables.net/jquery.dataTables.js') }}"></script>
    <script src="{{ asset('vendors/datatables.net-bs4/dataTables.bootstrap4.js') }}"></script>
    <script src="{{ asset('js/dataTables.select.min.js') }}"></script>

    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="{{ asset('js/off-canvas.js') }}"></script>
    <script src="{{ asset('js/hoverable-collapse.js') }}"></script>
    <script src="{{ asset('js/template.js') }}"></script>
    <script src="{{ asset('js/settings.js') }}"></script>
    <script src="{{ asset('js/todolist.js') }}"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="{{ asset('js/dashboard.js') }}"></script>
    <script src="{{ asset('js/Chart.roundedBarCharts.js') }}"></script>
    <!-- End custom js for this page-->

    {{-- <script src="https://cdn.datatables.net/2.0.1/js/dataTables.js"></script> --}}


    <script src="https://cdn.tiny.cloud/1/8fai9pbxzi4qrv4ijrbj7cmdep8quwby2p1yo0li32n829jj/tinymce/5/tinymce.min.js"
        referrerpolicy="origin"></script>
    <script src="{{ asset('js/tinymce_init.js') }}"></script>






    @yield('script')

</body>

</html>
