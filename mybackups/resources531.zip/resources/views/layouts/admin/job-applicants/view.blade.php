@extends('layouts.master')

@section('styles')
    @parent
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/intl-tel-input@17.0.3/build/css/intlTelInput.css">

    <style>
        .navigation {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .iti.iti--allow-dropdown.iti--separate-dial-code {
            width: 100%;
        }
    </style>
@endsection

@section('content')
    @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show mt-2" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    @if (Auth::user()->role == 'user')
        <nav aria-label="breadcrumb" class="mt-2">
            <ol class="breadcrumb">
                <li class="breadcrumb-item "> <a href="{{ route('applicants.index') }}"> Home </a> </li>
                <li class="breadcrumb-item"><a href="{{ route('applicants.index') }}">Applicants </a>
                <li class="breadcrumb-item bactive"><a href="{{ url()->current() }}">View </a>
                </li>
            </ol>
        </nav>
    @elseif(true)
        <nav aria-label="breadcrumb" class="mt-2">
            <ol class="breadcrumb">
                <li class="breadcrumb-item "> <a href="{{ route('dashboard') }}"> Home </a> </li>
                <li class="breadcrumb-item"><a href="{{ route('applicants.index') }}">Applicants </a>
                <li class="breadcrumb-item bactive"><a href="{{ url()->current() }}">View </a>
                </li>
            </ol>
        </nav>
    @endif

    <div class="viewdetialsbtn pr-1" style="text-align: right;">

        @if ($interviewdata && in_array($applicant->applicant_status, ['invited', 'reschedule_requested', 'accepted']))
            <span class="btn text-dark border rounded mb-3">
                @if ($interviewdata->time)
                    Schedule Time: {{ $interviewdata->time }}
                @endif

                @if ($interviewdata->time && $interviewdata->scheduled_at)
                    ,
                @endif

                @if ($interviewdata->scheduled_at)
                    Reschedule Time: {{ $interviewdata->scheduled_at }}
                @endif
            </span>
        @endif



        <span class="{{ $applicant->viewed > 0 ? 'btn text-success border rounded mb-3' : '' }}">Viewed</span>

        <a href="{{ route('applicants.editappli', ['id' => $applicant->id]) }}" class="btn btn-info mb-3"
            style="width:auto;">Edit / Update</a>

        <span class="dropdown">
            <a href="#" class="btn btn-success mb-3 dropdown-toggle " id="dropdownMenuLink" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                Invite Interview
            </a>
            <!-- Dropdown menu -->
            <div class="dropdown-menu px-2" aria-labelledby="dropdownMenuLink">
                <a class="dropdown-item pb-2" href="#" data-toggle="modal" data-target="#inPersonModal">In Person</a>
                <a class="dropdown-item pb-2" href="#" data-toggle="modal" data-target="#onlineModal">Online</a>
                <a class="dropdown-item pb-2" href="#" data-toggle="modal" data-target="#videoModal">Video</a>
            </div>
        </span>

        <form action="{{ route('updateStatus', ['id' => $applicant->id]) }}" class="sttausupate" method="POST"
            style="display: inline-block;">
            @csrf
            <span style="display: inline-block;" class="cfin">
                <select class="form-control statusSelect" name="status">
                    @foreach (['new_entry', 'accepted', 'checked', 'editted', 'invited', 'called', 'hired', 'rejected', 'under_review', 'shortlisted', 'pending', 'offer_extended', 'offer_accepted', 'offer_declined', 'reschedule_requested'] as $status)
                        <option value="{{ $status }}"
                            {{ $applicant->applicant_status == $status ? 'selected' : '' }}>
                            {{ ucfirst(str_replace('_', ' ', $status)) }}
                        </option>
                    @endforeach
                </select>
            </span>
            <button type="submit" class="btn btn-primary" style="border-radius: 7px !important;">Update Status</button>
        </form>



        <style>
            .statusSelect {
                background-color: rgb(36, 94, 58) !important;
                color: #fff !important;
            }

            form.sttausupate {
                position: relative;
                top: -7px;
            }
        </style>


    </div>

    <!-- Modals -->
    <div class="modal fade" id="inPersonModal" tabindex="-1" role="dialog" aria-labelledby="inPersonModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="inPersonModalLabel">In Person Interview</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body inpersonmodal">
                    <form method="POST" action="{{ route('interview.submit', ['id' => $applicant->id]) }}">
                        @csrf
                        <div class="form-group">
                            <label for="address">Address</label>
                            <input type="text" class="form-control" id="address" name="address">
                        </div>
                        <div class="form-group">
                            <label for="contactNumberPerson">Official Contact Number</label>
                            <input type="tel" class="form-control" id="contactNumberPerson" name="contactNumber">
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea class="form-control" id="message" name="message"> </textarea>
                        </div>
                        <div class="form-group">
                            <label for="time">Time Zone</label>
                            <input type="datetime-local" class="form-control" id="time" name="time" required>
                        </div>
                        <div class="form-group">
                            <label for="zonecountry">Time Zone Counry</label>
                            <select name="zonecountry" required class="form-control">
                                <option value="Dubai">Dubai</option>
                                <option value="India">India</option>
                                <option value="Nepal">Nepal</option>
                                <option value="Pakistan">Pakistan</option>
                                <option value="Bangladesh">Bangladesh</option>
                                <option value="Philippines">Philippines</option>
                                <option value="Philippines">Indonesia</option>
                                <option value="Philippines">Sri Lanka</option>
                            </select>
                        </div>
                        <input type="hidden" class="form-control" value="methodperson" id="methodperson"
                            name="methodperson">
                        <input type="submit" class="form-control bg-dark text-light" value="Submit">
                    </form>
                    <script>
                        const datetimeInput = document.getElementById('time');
                        const ampmSelect = document.getElementById('ampm');

                        ampmSelect.addEventListener('change', () => {
                            const datetimeValue = datetimeInput.value.split('T')[1];
                            const time = datetimeValue.split(':');
                            let hour = parseInt(time[0]);

                            // Convert to 12-hour format
                            if (ampmSelect.value === 'PM' && hour < 12) {
                                hour += 12;
                            } else if (ampmSelect.value === 'AM' && hour === 12) {
                                hour = 0;
                            }

                            // Update datetime input value
                            datetimeInput.value =
                                `${datetimeInput.value.split('T')[0]}T${hour.toString().padStart(2, '0')}:${time[1]}`;
                        });
                    </script>

                </div>


            </div>
        </div>
    </div>

    <div class="modal fade" id="onlineModal" tabindex="-1" role="dialog" aria-labelledby="onlineModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="onlineModalLabel">Online Interview</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('interview.submit', ['id' => $applicant->id]) }}">
                        @csrf
                        <div class="form-group">
                            <label for="meetingurl">Online Meet/Zoom Link</label>
                            <input type="text" class="form-control" id="meetingurl" name="meetingurl">
                        </div>
                        <div class="form-group" id="OnlineParent">
                            <label for="contactNumberOnline">Official Contact Number</label>
                            <input type="tel" class="form-control" id="contactNumberOnline" name="contactNumber">
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea class="form-control" id="message" name="message"> </textarea>
                        </div>
                        <div class="form-group">
                            <label for="time">Time Zone</label>
                            <input type="datetime-local" class="form-control" id="time" name="time" required>
                        </div>
                        <div class="form-group">
                            <label for="zonecountry">Time Zone Counry</label>
                            <select name="zonecountry" required class="form-control">
                                <option value="India">Dubai</option>
                                <option value="India">India</option>
                                <option value="Nepal">Nepal</option>
                                <option value="Pakistan">Pakistan</option>
                                <option value="Bangladesh">Bangladesh</option>
                                <option value="Philippines">Philippines</option>
                                <option value="Philippines">Indonesia</option>
                                <option value="Philippines">Sri Lanka</option>
                            </select>
                        </div>
                        <input type="hidden" class="form-control" value="Online" id="methodperson"
                            name="methodperson">
                        <input type="submit" class="form-control bg-dark text-light" value="Submit">
                    </form>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="videoModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="videoModalLabel">Video Interview</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="{{ route('interview.submit', ['id' => $applicant->id]) }}">
                        @csrf
                        <div class="form-group">
                            <label for="meetingurl">Online Meet/Zoom Link</label>
                            <input type="text" class="form-control" id="meetingurl" name="meetingurl">
                        </div>
                        <div class="form-group">
                            <label for="contactNumberVideo">Official Contact Number</label>
                            <input type="tel" class="form-control" id="contactNumberVideo" name="contactNumber">
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea class="form-control" id="message" name="message"> </textarea>
                        </div>
                        <div class="form-group">
                            <label for="time">Time Zone</label>
                            <input type="datetime-local" class="form-control" id="time" name="time" required>
                        </div>
                        <div class="form-group">
                            <label for="zonecountry">Time Zone Counry</label>
                            <select name="zonecountry" required class="form-control">
                                <option value="India">Dubai</option>
                                <option value="India">India</option>
                                <option value="Nepal">Nepal</option>
                                <option value="Pakistan">Pakistan</option>
                                <option value="Bangladesh">Bangladesh</option>
                                <option value="Philippines">Philippines</option>
                                <option value="Philippines">Indonesia</option>
                                <option value="Philippines">Sri Lanka</option>
                            </select>
                        </div>
                        <input type="hidden" class="form-control" value="video" id="methodperson"
                            name="methodperson">
                        <input type="submit" class="form-control bg-dark text-light" value="Submit">
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div>
        <div class="row">
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header">
                        Personal Details
                    </div>
                    <div class="card-body border pt-3 pb-3 pb-0 mb-0 mt-2">
                        <table class="table border mb-0">
                            <tbody>
                                <tr>
                                    <th scope="row" class="border-right">Applicannt Submitted</th>
                                    <td class="border-left">{{ $applicant->created_at }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Nationality</th>
                                    <td class="border-left">{{ $applicant->nationality }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Country</th>
                                    <td class="border-left">{{ $applicant->country }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Province</th>
                                    <td class="border-left">{{ $applicant->province }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">City</th>
                                    <td class="border-left">{{ $applicant->city }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Zip Code</th>
                                    <td class="border-left">{{ $applicant->zip }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Home Address</th>
                                    <td class="border-left">{{ $applicant->homeaddrss }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">UAE Resident</th>
                                    <td class="border-left">
                                        @if ($applicant->uaeresident == '1')
                                            Yes
                                        @endif
                                        @if ($applicant->uaeresident == '0')
                                            NO
                                        @endif
                                    </td>
                                </tr>

                                @if ($applicant->uaeresident)
                                    <tr>
                                        <th scope="row" class="border-right">Emirates ID</th>
                                        <td class="border-left">{{ $applicant->emiratesid }}</td>
                                    </tr>
                                    <tr>
                                        <th scope="row" class="border-right">Expiry Date</th>
                                        <td class="border-left">{{ $applicant->emirates_expiry }}</td>
                                    </tr>
                                @endif

                                <tr>
                                    <th scope="row" class="border-right">First Name</th>
                                    <td class="border-left">{{ $applicant->first_name }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Last Name</th>
                                    <td class="border-left">{{ $applicant->last_name }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Mother Name</th>
                                    <td class="border-left">{{ $applicant->mother_name }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Father Name</th>
                                    <td class="border-left">{{ $applicant->father_name }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Date of Birth</th>
                                    <td class="border-left">{{ $applicant->date_of_birth }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Martial Status</th>
                                    <td class="border-left">{{ $applicant->martialstatus }}</td>
                                </tr>
                                
                                <tr>
                                    <th scope="row" class="border-right">Contact Number</th>
                                    <td class="border-left">{{ $applicant->contact_number }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">WhatsApp Number</th>
                                    <td class="border-left">{{ $applicant->whatsapp_number }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Email</th>
                                    <td class="border-left">{{ $applicant->email }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Driving Number</th>
                                    <td class="border-left">{{ $applicant->appli_dri_number }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Passport No</th>
                                    <td class="border-left">{{ $applicant->passportno }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Date of Expiry</th>
                                    <td class="border-left">{{ $applicant->date_of_expiry }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Submission ID</th>
                                    <td class="border-left">{{ $applicant->submissionid }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Applicant Status</th>
                                    <td class="border-left">
                                        {{ ucfirst(str_replace('_', ' ', $applicant->applicant_status)) }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Email Verified</th>
                                    <td class="border-left">
                                        {{ $applicant->otp_verified == 1 ? 'Verified' : 'Not Verified' }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="border-right">Reference</th>
                                    <td class="border-left">
                                        {{ in_array($applicant->reference, ['PK2024S7', 'KP2024P3', 'MS2024K8', 'MN2024U5', 'SZ2024A9']) ? $applicant->reference : 'No' }}
                                    </td>

                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>

            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header">
                        Documents
                    </div>
                    <div class="card-body border pt-2 pb-3 mb-3 mt-2">
                        <!-- Thumbnails -->
                        <div class="mb-4">
                            <strong>Applicant Image:</strong><br>

                            <a href="{{ asset('applicants/' . $applicant->applicant_image) }}" data-lightbox="image-set"
                                data-title="Applicant Image">
                                <img src="{{ asset('applicants/' . $applicant->applicant_image) }}" width="70"
                                    class="img-thumbnail mt-1 mb-1" alt="Applicant Image">
                            </a>

                            <br>
                            <a href="{{ asset('applicants/' . $applicant->applicant_image) }}" download>Download Image</a>
                        </div>

                        <!-- PDF Viewer Section -->
                        @if ($applicant->nid_cnic_front)
                            <div class="mb-4">
                                <strong>Applicant NID/CNIC Front:</strong><br>
                                <embed src="{{ asset('applicants/' . $applicant->nid_cnic_front) }}" width="100px"
                                    height="100px" /> <br>
                                <a href="{{ asset('applicants/' . $applicant->nid_cnic_front) }}" target="_blank">View
                                    NID/CNIC Front</a>
                            </div>
                        @endif

                        @if ($applicant->nid_cnic_back)
                            <div class="mb-4">
                                <strong>Applicant NID/CNIC Back:</strong><br>
                                <embed src="{{ asset('applicants/' . $applicant->nid_cnic_back) }}" width="100px"
                                    height="100px" /> <br>
                                <a href="{{ asset('applicants/' . $applicant->nid_cnic_back) }}" target="_blank">View
                                    NID/CNIC Back</a>
                            </div>
                        @endif


                        <!-- PDF Viewer Section -->
                        @if ($applicant->applicant_passport)
                            <div class="mb-4">
                                <strong>Applicant Passport:</strong><br>
                                <embed src="{{ asset('applicants/' . $applicant->applicant_passport) }}" width="100px"
                                    height="100px" /> <br>
                                <a href="{{ asset('applicants/' . $applicant->applicant_passport) }}"
                                    target="_blank">View
                                    Passport PDF</a>
                            </div>
                        @endif

                        @if ($applicant->applicant_resume)
                            <div class="mb-4">
                                <strong>Applicant Resume:</strong><br>
                                <embed src="{{ asset('applicants/' . $applicant->applicant_resume) }}" width="100px"
                                    height="100px" /> <br>
                                <a href="{{ asset('applicants/' . $applicant->applicant_resume) }}" target="_blank">View
                                    Resume
                                    PDF</a>
                            </div>
                        @endif

                        @if ($applicant->appli_dri_lisence_frontpart)
                            <div class="mb-4">
                                <strong>Applicant Driving License Front Side:</strong><br>
                                <embed src="{{ asset('applicants/' . $applicant->appli_dri_lisence_frontpart) }}"
                                    width="100px" height="100px" /> <br>
                                <a href="{{ asset('applicants/' . $applicant->appli_dri_lisence_frontpart) }}"
                                    target="_blank">View Front Side PDF</a>
                            </div>
                        @endif

                        @if ($applicant->appli_dri_lisence_backpart)
                            <div class="mb-4">
                                <strong>Applicant Driving License Back Side:</strong><br>
                                <embed src="{{ asset('applicants/' . $applicant->appli_dri_lisence_backpart) }}"
                                    width="100px" height="100px" /> <br>
                                <a href="{{ asset('applicants/' . $applicant->appli_dri_lisence_backpart) }}"
                                    target="_blank">View Back Side PDF</a>
                            </div>
                        @endif

                        @if ($applicant->specialpage)
                            <div class="mb-4">
                                <strong>Special Page:</strong><br>
                                <embed src="{{ asset('applicants/' . $applicant->specialpage) }}" width="100px"
                                    height="100px" /> <br>
                                <a href="{{ asset('applicants/' . $applicant->specialpage) }}" target="_blank">View
                                    Special Page PDF</a>
                            </div>
                        @endif

                    </div>
                </div>
            </div>
        </div>

        <div class="navigation mb-3 mx-1">
            <style>
                .fbig {
                    font-size: 16px;
                }

                .navigation .btn {
                    padding: 7px;
                }
            </style>
            <!-- First applicant button/link -->
            <a href="{{ route('applicants.show', $firstApplicant->id) }}"
                class="btn btn-warning mr-2 w-100 fbig">First</a>

            <!-- Previous applicant button/link -->
            @if ($previousApplicant)
                <a href="{{ route('applicants.show', $previousApplicant->id) }}"
                    class="btn btn-warning mr-2 w-100 fbig">Previous</a>
            @else
                <button class="btn btn-warning mr-2 w-100 fbig" disabled>Previous</button>
            @endif

            <!-- Next applicant button/link -->
            @if ($nextApplicant)
                <a href="{{ route('applicants.show', $nextApplicant->id) }}"
                    class="btn btn-warning mr-2 w-100 fbig">Next</a>
            @else
                <button class="btn btn-warning mr-2 w-100 fbig" disabled>Next</button>
            @endif

            <!-- Last applicant button/link -->
            <a href="{{ route('applicants.show', $lastApplicant->id) }}" class="btn btn-warning w-100">Last</a>
        </div>

    </div>
@endsection

@section('script')
    @parent
    <!-- Lightbox JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>
@endsection
