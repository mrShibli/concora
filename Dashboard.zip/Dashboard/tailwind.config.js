/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['*'],
  theme: {
    screens:{
      'Tablet': '640px', 
      'Laptop': '1024px', 
      'Desktop': '1280px', 
    },
    extend: {
      colors:{
        'blue-c': '#302bbe',
        'light-c': '#b3c8ec',
        'white-c': '#ffffff',
        'black-c': '#000000'
      }
    },
  },
  plugins: [],
}

